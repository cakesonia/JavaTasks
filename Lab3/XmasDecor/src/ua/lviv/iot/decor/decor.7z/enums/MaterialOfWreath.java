/**
 * 
 */
package ua.lviv.iot.decor.enums;

/**
 * @author Dell
 *
 */
public enum MaterialOfWreath {
    BRANCHES, CONES, TAPES
}
