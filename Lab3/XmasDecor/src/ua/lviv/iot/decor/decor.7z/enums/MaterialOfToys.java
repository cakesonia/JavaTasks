/**
 * 
 */
package ua.lviv.iot.decor.enums;

/**
 * @author Dell
 *
 */
public enum MaterialOfToys {
    GLASS, TEXTILE, PAPER
}
