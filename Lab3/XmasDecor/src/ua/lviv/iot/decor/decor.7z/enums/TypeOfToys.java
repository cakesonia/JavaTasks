/**
 * 
 */
package ua.lviv.iot.decor.enums;

/**
 * @author Dell
 *
 */
public enum TypeOfToys {
    ROUND, ANIMALS, ANGELS, STARS
}
