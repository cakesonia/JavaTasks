/**
 * 
 */
package ua.lviv.iot.decor.enums;

/**
 * @author Dell
 *
 */
/*public enum DecorType {
    HOUSE, YARD, XMAS_TREE
}
*/