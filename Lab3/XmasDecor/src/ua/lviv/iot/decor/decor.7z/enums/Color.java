/**
 * 
 */
package ua.lviv.iot.decor.enums;

/**
 * @author Dell
 *
 */
public enum Color {
    BLUE, GREEN, RED, YELLOW
}
